<!DOCTYPE html>
<html>

<body>
<h1>MOI</h1>

<p>
<?php

echo "moi";

?>
</p>
</body>
</html>
