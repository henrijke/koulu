<?php

echo "<br><h1>Patient test</h1>";
include 'TestPatient.php';
echo "<br><h1>Person test</h1>";
include 'TestPhp.php';
echo "<br><h1>WeightWatcher test</h1>";
include 'TestWeightWatcher.php';